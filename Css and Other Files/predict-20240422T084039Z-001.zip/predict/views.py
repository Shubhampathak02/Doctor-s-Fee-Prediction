from django.shortcuts import render 
from django.views.decorators.csrf import csrf_exempt
import joblib
import numpy as np
import os
model_path = os.path.join('models', 'model_lr.pkl')
scaler_path = os.path.join('models', 'scaler.pkl')

# Load your model and scaler
model = joblib.load(model_path)
scaler = joblib.load(scaler_path)

def index(request):
    return render(request, 'welcome.html')
@csrf_exempt
def enter_input(request):
    if request.method == 'POST':
        speciality = request.POST.get('Speciality')
        experience = int(request.POST.get('Experience'))
        City = request.POST.get('City')
        dp_score = int(request.POST.get('dp_score'))
        npv = int(request.POST.get('npv'))
        
        speciality_dict={'Dietitian/Nutritionist':0, 'Dentist':0, 'Physiotherapist':0,
       'Chiropractor':0, 'Dermatologist':0, 'Gynecologist':0,
       'Infertility Specialist':0, 'Pediatrician':0, 'Orthopedist':0,
       'Pulmonologist':0, 'Cardiologist':0, 'Rheumatologist':0,
       'Gastroenterologist':0, 'Neurologist':0, 'Bariatric Surgeon':0,
       'Neurosurgeon':0, 'Ophthalmologist':0, 'Psychiatrist':0, 'Urologist':0}   
        city_dict={'Bangalore':0, 'Mumbai':0, 'Delhi':0}
        to_scale = [[experience, dp_score, npv]]
        for key,value in speciality_dict.items():
            if key == speciality:
                value+=1
            else:
                pass
        for key,value in city_dict.items():
            if key == City:
                value+=1
            else:
                pass
        try:
            scaled = scaler.transform(to_scale)
        except:
            print("prb with scaling")
        # Reshape scaled_features to have the same number of dimensions as unscaled_features
        scaled = scaled[0]
        to_not_scale = [speciality_dict['Cardiologist'],speciality_dict['Chiropractor'] ,speciality_dict['Dentist'], speciality_dict['Dermatologist'],speciality_dict['Dietitian/Nutritionist'], speciality_dict['Gastroenterologist'],speciality_dict['Gynecologist'], speciality_dict['Infertility Specialist'],speciality_dict['Neurologist'], speciality_dict['Neurosurgeon'],speciality_dict['Ophthalmologist'], speciality_dict['Orthopedist'],speciality_dict['Pediatrician'], speciality_dict['Physiotherapist'],speciality_dict['Psychiatrist'], speciality_dict['Pulmonologist'],speciality_dict['Rheumatologist'], speciality_dict['Urologist'], city_dict['Delhi'], city_dict['Mumbai']]
        
        try:
        # Combine the features
            input_data = np.hstack((scaled,to_not_scale))
        except:
            print("prb with hstacking")
            print(scaled)
            print(to_not_scale)

        print(np.shape(scaled),np.shape(to_not_scale))
        y_pred = model.predict(input_data.reshape(1,-1))[0]
        predictions = round(y_pred,2)

            # Perform your calculations
        # calculated_value = lr.predict([predict_input.reshape(1, -1)])
        calculated_value=1
        print(predictions)
            # Redirect to the next page with the calculated value
        return render(request,'page3.html',{'value':predictions})
    else:
        return render(request, 'page2.html')
