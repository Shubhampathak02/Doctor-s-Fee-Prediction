from django.urls import path
from . import views

urlpatterns=[
    path('', views.index, name='dashboard-welcome'),
    path('page2.html', views.enter_input, name='input-pg2'),
    path('page3.html', views.enter_input, name='result-pg3'),
]
