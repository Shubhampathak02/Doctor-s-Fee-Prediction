# from django.db import models

# class Doctor(models.Model):
#     speciality = models.CharField(max_length=100)
#     experience = models.IntegerField()
#     city = models.CharField(max_length=100)
#     dp_score = models.FloatField()
#     npv = models.FloatField()
